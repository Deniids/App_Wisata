@extends('wisatas.layout')

@section('content')
    
<img src="{{Storage::url('public/images/'. $wisata->image)}}" alt="" style="width: 500px">
<br><br>
<h3>{{$wisata->nama}}</h3>
<p>{{$wisata->kota}}</p>
<p>{{$wisata->harga_tiket}}</p>

<a href="{{route('wisatas.index')}}" class="btn btn-secondary">Back Home</a>
@endsection