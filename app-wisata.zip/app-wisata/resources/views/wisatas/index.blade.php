@extends('wisatas.layout')

@section('content')

<a href="{{route('wisatas.create')}}" class="btn btn-primary">Add</a>

<table class="table">
<tr>
    <th>ID</th>
    <th>Image</th>
    <th>Nama</th>
    <th>Kota</th>
    <th>Harga Tiket</th>
    <th>Action</th>
</tr>
@foreach ($wisatas as $wisata)
<tr>
<td>{{$wisata->id}}</td>
<td><img src="{{Storage::url('public/images/' . $wisata->image)}}" alt="" style="width: 180px;"></td>
<td>{{$wisata->nama}}</td>
<td>{{$wisata->kota}}</td>
<td>{{$wisata->harga_tiket}}</td>
<td>
    <a href="{{route('wisatas.show',$wisata->id)}}" class="btn btn-success">Show</a>
    <a href="{{route('wisatas.edit',$wisata->id)}}" class="btn btn-warning">Edit</a>
    <form action="{{route('wisatas.destroy',$wisata->id)}}" method="post" style="display: inline">
@csrf
@method('DELETE')
<button class="btn btn-danger">Delete</button>
</form>
</td>
</tr>
@endforeach
</table>
{{$wisatas->links()}}
@endsection