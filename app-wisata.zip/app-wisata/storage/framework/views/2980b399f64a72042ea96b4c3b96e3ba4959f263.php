<?php $__env->startSection('content'); ?>
    
<img src="<?php echo e(Storage::url('public/images/'. $wisata->image)); ?>" alt="" style="width: 500px">
<br><br>
<h3><?php echo e($wisata->nama); ?></h3>
<p><?php echo e($wisata->kota); ?></p>
<p><?php echo e($wisata->harga_tiket); ?></p>

<a href="<?php echo e(route('wisatas.index')); ?>" class="btn btn-secondary">Back Home</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('wisatas.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siswa/Documents/app-wisata/resources/views/wisatas/show.blade.php ENDPATH**/ ?>