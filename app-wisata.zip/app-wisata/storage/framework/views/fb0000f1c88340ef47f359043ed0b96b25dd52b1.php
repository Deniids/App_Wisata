<?php $__env->startSection('content'); ?>
    
<form action="<?php echo e(route('wisatas.store')); ?>" method="post" enctype="multipart/form-data" class="form">
<?php echo csrf_field(); ?>

<label for="">Nama</label>
<input type="text" name="nama" id=""><br>

<label for="">Kota</label>
<input type="text" name="kota" id=""><br>

<label for="">Harga Tiket</label>
<input type="number" name="harga_tiket" id=""><br>

<label for="">Upload Image</label>
<input type="file" name="image" id=""><br><br>

<input type="submit" value="Save" class="btn btn-primary">

</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('wisatas.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siswa/Documents/app-wisata/resources/views/wisatas/create.blade.php ENDPATH**/ ?>